import torch
import time
import math
import torch.optim as optim
import numpy as np
import os
from scipy.sparse import csr_matrix

from GLCPN.model.GLCPN_ui import GLCPN
from GLCPN.utils.eval import eval
from GLCPN.utils.LoadData_ui import Data
# GPU allocation
torch.cuda.set_device(0)
device = torch.device("cuda")
os.environ["CUDA_VISIBLE_DEVICES"] = "0, 1"
device_ids = [0, 1]

def main(LR, L2, batch_size, dataset_name, optimizer_type, latent_dim, n_layers, idx, alpha, use_linear, use_priori, use_holistic, idx_withouttime):
    """
    main fuction: train, val, and test

    :param LR:
    :param L2:
    :param batch_size:
    :param dataset_name:
    :param optimizer_type:
    :param latent_dim:
    :param n_layers:
    :param idx:
    :param alpha:
    :param use_linear:
    :param use_priori:
    :param use_holistic:
    :param idx_withouttime:
    :return:
    """
    # Load the data
    data = Data("/home/lf/Bifanghui/geometric/data/" + dataset_name + "/train" + str(idx_withouttime) + ".txt",
                "/home/lf/Bifanghui/geometric/data/" + dataset_name + "/val" + str(idx_withouttime) + ".txt",
                "/home/lf/Bifanghui/geometric/data/" + dataset_name + "/test" + str(idx_withouttime) + ".txt",
                dataset_name, batch_size, use_priori=use_priori, use_holistic=use_holistic)

    # fetch the model
    model = GLCPN(num_rows=data.max_row_id, num_cols=data.max_col_id, latent_dim=latent_dim,
                        n_layers=n_layers, ui_graph=data.ui_graph, alpha=alpha,
                        degree=data.degree, use_holistic=use_holistic, use_linear=use_linear)
    model = model.cuda()

    # optimizer configuration
    if optimizer_type == "SGD":
        optimizer = optim.SGD(model.parameters(), lr=LR, weight_decay=L2)
    elif optimizer_type == "Adam":
        optimizer = optim.Adam(model.parameters(), lr=LR, weight_decay=L2)
    else:
        raise ValueError('Unknown optimizer_type.')

    # the saved address for result_file configuration
    save_dir = "result/" + optimizer_type + "/" + dataset_name + "/"
    val_result_file = open(save_dir
                           + "val"
                           + "_" + dataset_name
                           + "_" + optimizer_type
                           + "_dim=" + str(latent_dim)
                           + "_n_layers=" + str(n_layers)
                           + "_lr=" + str(LR)
                           + "_alpha=" + str(alpha)
                           + "_l2=" + str(L2)
                           + "_idx=" + str(idx)
                           + "_BS=" + str(batch_size)
                           + "_L=" + str(use_linear)
                           + "_P=" + str(use_priori)
                           + "_H=" + str(use_holistic)
                           + ".txt", "w")
    test_result_file = open(save_dir
                           + "test"
                           + "_" + dataset_name
                           + "_" + optimizer_type
                           + "_dim=" + str(latent_dim)
                           + "_n_layers=" + str(n_layers)
                           + "_lr=" + str(LR)
                           + "_alpha=" + str(alpha)
                           + "_l2=" + str(L2)
                           + "_idx=" + str(idx)
                           + "_BS=" + str(batch_size)
                           + "_L=" + str(use_linear)
                           + "_P=" + str(use_priori)
                           + "_H=" + str(use_holistic)
                           + ".txt", "w")

    # console information
    print(dataset_name + "\n"
          + optimizer_type + "\n"
          + "latent_dim=" + str(latent_dim) + "\n"
          + "n_layers=" + str(n_layers) + "\n"
          + "learningRate=" + str(LR) + "\n"
          + "alpha=" + str(alpha) + "\n"
          + "l2=" + str(L2) + "\n"
          + "idx=" + str(idx) + "\n"
          + "L=" + str(use_linear) + "\n"
          + "P=" + str(use_priori) + "\n"
          + "H=" + str(use_holistic) + "\n"
          + "batchSize=" + str(batch_size))

    # some hyparameters initialization
    num_epochs = 1000
    min_val_RMSE = 10000
    min_val_MAE = 10000
    max_val_R2 = -10000
    max_val_NDCG = -10000
    min_val_index_RMSE = 0
    min_val_index_MAE = 0
    max_val_index_R2 = 0
    max_val_index_NDCG = 0
    top_k = 20
    all_start_time = time.time()

    for i in range(num_epochs):
        # switch to train mode
        model.train()
        torch.cuda.synchronize()
        start_time = time.time()

        """
            Model Train
        """
        train_RMSE = 0.0
        train_MAE = 0.0
        train_SSE = 0.0
        train_SST = 0.0
        train_NDCG = 0.0

        row_random, col_random, labels_random, total_batch, num = data.train_iterate_one_epoch(batch_size)
        for train_idx in range(total_batch + 1):
            model.training = True
            if train_idx == total_batch:
                batch_row = torch.LongTensor(row_random[train_idx * batch_size:]).cuda()
                batch_col = torch.LongTensor(col_random[train_idx * batch_size:]).cuda()
                batch_label = torch.Tensor(labels_random[train_idx * batch_size:]).cuda()
            else:
                batch_row = torch.LongTensor(row_random[train_idx * batch_size:(train_idx + 1) * batch_size]).cuda()
                batch_col = torch.LongTensor(col_random[train_idx * batch_size:(train_idx + 1) * batch_size]).cuda()
                batch_label = torch.Tensor(labels_random[train_idx * batch_size:(train_idx + 1) * batch_size]).cuda()

            # optimizer
            optimizer.zero_grad()
            preds = model.forward(row_input=batch_row, col_input=batch_col)
            preds = torch.reshape(preds, (-1,))
            loss = torch.sum(torch.pow((batch_label - preds), 2))
            loss.backward()
            optimizer.step()

            # Cumulative Evaluation
            temp_train_RMSE, temp_train_MAE, temp_train_SSE, temp_train_SST \
                = eval(batch_label, preds, data.train_truth_mean)
            train_RMSE += temp_train_RMSE
            train_MAE += temp_train_MAE
            train_SSE += temp_train_SSE
            train_SST += temp_train_SST

            if train_idx == 0:
                all_preds = preds.cpu().detach().numpy()
            else:
                # all_preds = torch.cat((all_preds, preds))
                all_preds = np.append(all_preds, preds.cpu().detach().numpy())

        torch.cuda.synchronize()
        end_time = time.time()

        # Eval
        train_RMSE = math.sqrt(train_RMSE / num)
        train_MAE = train_MAE / num
        train_R2 = 1 - (train_SSE / train_SST)

        row_col_predictions_train = csr_matrix(
            (all_preds, (row_random, col_random)), shape=(
                data.max_row_id, data.max_col_id), dtype='float32')
        train_DCG = np.zeros(data.max_row_id)
        # Train DGC for each node
        for u in range(data.max_row_id):
            sorted_indices = np.argsort(row_col_predictions_train[u].data)[::-1]
            cur_sorted_ratings = data.train_data[u].data[sorted_indices]
            # NDCG_20
            real_k = min(top_k, len(cur_sorted_ratings))
            for k in range(real_k):
                train_DCG[u] += ((2 ** (cur_sorted_ratings[k]) - 1) / np.log2(k + 2))
            if data.train_IDCG[u] != 0:
                train_NDCG += (train_DCG[u] / data.train_IDCG[u])

        train_NDCG = train_NDCG / data.max_row_id

        print(str(i) + "-train: \t"
              + "RMSE: " + str(train_RMSE) + "\t"
              + "MAE: " + str(train_MAE) + "\t"
              + "R2: " + str(train_R2) + "\t"
              + "NDCG: " + str(train_NDCG))

        """
            Model Val
        """
        val_RMSE = 0.0
        val_MAE = 0.0
        val_SSE = 0.0
        val_SST = 0.0
        val_NDCG = 0.0
        row_random, col_random, labels_random, total_batch, num = data.val_iterate_one_epoch(batch_size)
        for val_idx in range(total_batch + 1):
            model.training = False
            if val_idx == total_batch:
                batch_row = torch.LongTensor(row_random[val_idx * batch_size:]).cuda()
                batch_col = torch.LongTensor(col_random[val_idx * batch_size:]).cuda()
                batch_label = torch.Tensor(labels_random[val_idx * batch_size:]).cuda()
            else:
                batch_row = torch.LongTensor(row_random[val_idx * batch_size:(val_idx + 1) * batch_size]).cuda()
                batch_col = torch.LongTensor(col_random[val_idx * batch_size:(val_idx + 1) * batch_size]).cuda()
                batch_label = torch.Tensor(labels_random[val_idx * batch_size:(val_idx + 1) * batch_size]).cuda()

            preds = model.forward(row_input=batch_row, col_input=batch_col)
            preds = torch.reshape(preds, (-1,))

            temp_val_RMSE, temp_val_MAE, temp_val_SSE, temp_val_SST \
                = eval(batch_label, preds, data.val_truth_mean)
            val_RMSE += temp_val_RMSE
            val_MAE += temp_val_MAE
            val_SSE += temp_val_SSE
            val_SST += temp_val_SST

            if val_idx == 0:
                all_preds = preds.cpu().detach().numpy()
            else:
                all_preds = np.append(all_preds, preds.cpu().detach().numpy())

        # Eval
        val_RMSE = math.sqrt(val_RMSE / num)
        val_MAE = val_MAE / num
        val_R2 = 1 - (val_SSE / val_SST)

        row_col_predictions_val = csr_matrix(
            (all_preds, (row_random, col_random)), shape=(
                data.max_row_id, data.max_col_id), dtype='float32')
        val_DCG = np.zeros(data.max_row_id)
        # Val DCG for each node
        for u in range(data.max_row_id):
            sorted_indices = np.argsort(row_col_predictions_val[u].data)[::-1]
            cur_sorted_ratings = data.val_data[u].data[sorted_indices]
            real_k = min(top_k, len(cur_sorted_ratings))
            for k in range(real_k):
                val_DCG[u] += ((2 ** (cur_sorted_ratings[k]) - 1) / np.log2(k + 2))
            if data.val_IDCG[u] != 0:
                val_NDCG += (val_DCG[u] / data.val_IDCG[u])
        val_NDCG = val_NDCG / data.max_row_id

        print(str(i) + "---val: \t"
              + "RMSE: " + str(val_RMSE) + "\t"
              + "MAE: " + str(val_MAE) + "\t"
              + "R2: " + str(val_R2) + "\t"
              + "NDCG: " + str(val_NDCG))
        print()
        val_result_file.write(str(i) + "\t"
                              + str(val_RMSE) + "\t"
                              + str(val_MAE) + "\t"
                              + str(val_R2) + "\t"
                              + str(val_NDCG) + "\t"
                              + str(end_time - start_time) + "\n")
        val_result_file.flush()

        """
            Model Test
        """
        test_RMSE = 0.0
        test_MAE = 0.0
        test_SSE = 0.0
        test_SST = 0.0
        test_NDCG = 0.0
        row_random, col_random, labels_random, total_batch, num = data.test_iterate_one_epoch(batch_size)
        for test_idx in range(total_batch + 1):
            model.training = False
            if test_idx == total_batch:
                batch_row = torch.LongTensor(row_random[test_idx * batch_size:]).cuda()
                batch_col = torch.LongTensor(col_random[test_idx * batch_size:]).cuda()
                batch_label = torch.Tensor(labels_random[test_idx * batch_size:]).cuda()
            else:
                batch_row = torch.LongTensor(row_random[test_idx * batch_size:(test_idx + 1) * batch_size]).cuda()
                batch_col = torch.LongTensor(col_random[test_idx * batch_size:(test_idx + 1) * batch_size]).cuda()
                batch_label = torch.Tensor(labels_random[test_idx * batch_size:(test_idx + 1) * batch_size]).cuda()

            preds = model.forward(row_input=batch_row, col_input=batch_col)
            preds = torch.reshape(preds, (-1,))

            temp_test_RMSE, temp_test_MAE, temp_test_SSE, temp_test_SST \
                = eval(batch_label, preds, data.test_truth_mean)
            test_RMSE += temp_test_RMSE
            test_MAE += temp_test_MAE
            test_SSE += temp_test_SSE
            test_SST += temp_test_SST

            if test_idx == 0:
                all_preds = preds.cpu().detach().numpy()
            else:
                all_preds = np.append(all_preds, preds.cpu().detach().numpy())

        # Eval
        test_RMSE = math.sqrt(test_RMSE / num)
        test_MAE = test_MAE / num
        test_R2 = 1 - (test_SSE / test_SST)

        row_col_predictions_test = csr_matrix(
            (all_preds, (row_random, col_random)), shape=(
                data.max_row_id, data.max_col_id), dtype='float32')
        test_DCG = np.zeros(data.max_row_id)
        # Test DCG for each node
        for u in range(data.max_row_id):
            sorted_indices = np.argsort(row_col_predictions_test[u].data)[::-1]
            cur_sorted_weights = data.test_data[u].data[sorted_indices]
            # NDCG_20
            real_k = min(top_k, len(cur_sorted_weights))
            for k in range(real_k):
                test_DCG[u] += ((2 ** (cur_sorted_weights[k]) - 1) / np.log2(k + 2))
            if data.test_IDCG[u] != 0:
                test_NDCG += (test_DCG[u] / data.test_IDCG[u])
        test_NDCG = test_NDCG / data.max_row_id

        test_result_file.write(str(i) + "\t"
                               + str(test_RMSE) + "\t"
                               + str(test_MAE) + "\t"
                               + str(test_R2) + "\t"
                               + str(test_NDCG) + "\t"
                               + str(end_time - start_time) + "\n")

        test_result_file.flush()
        # Early Stop
        if val_RMSE < min_val_RMSE:
            min_val_RMSE = val_RMSE
            min_test_RMSE = test_RMSE
            min_val_index_RMSE = i
            all_end_time_RMSE = end_time
        if val_MAE < min_val_MAE:
            min_val_MAE = val_MAE
            min_test_MAE = test_MAE
            min_val_index_MAE = i
            all_end_time_MAE = end_time
        if val_R2 > max_val_R2:
            max_val_R2 = val_R2
            max_test_R2 = test_R2
            max_val_index_R2 = i
            all_end_time_R2 = end_time
        if val_NDCG > max_val_NDCG:
            max_val_NDCG = val_NDCG
            max_test_NDCG = test_NDCG
            max_val_index_NDCG = i
            all_end_time_NDCG = end_time

        if i - min_val_index_RMSE > 30 and i - min_val_index_RMSE > 30 and \
                i - max_val_index_R2 > 30  and i - max_val_index_NDCG > 30 :
            break
    all_time_minRMSE = all_end_time_RMSE - all_start_time
    all_time_minMAE = all_end_time_MAE - all_start_time
    all_time_maxR2 = all_end_time_R2 - all_start_time
    all_time_maxNDCG = all_end_time_NDCG - all_start_time

    per_time_avg_RMSE = all_time_minRMSE / (min_val_index_RMSE + 1)
    per_time_avg_MAE = all_time_minMAE / (min_val_index_MAE + 1)
    per_time_avg_R2 = all_time_maxR2 / (max_val_index_R2 + 1)
    per_time_avg_NDCG = all_time_maxNDCG / (max_val_index_NDCG + 1)

    print('min_val_RMSE: ' + str(min_val_RMSE))
    print('min_val_MAE: ' + str(min_val_MAE))
    print('max_val_R2: ' + str(max_val_R2))
    print('max_val_NDCG: ' + str(max_val_NDCG))

    print('min_test_RMSE: ' + str(min_test_RMSE))
    print('min_test_MAE: ' + str(min_test_MAE))
    print('min_test_R2: ' + str(max_test_R2))
    print('min_test_NDCG: ' + str(max_test_NDCG))

    print("all_time_minRMSE: " + str(all_time_minRMSE))
    print("all_time_minMAE: " + str(all_time_minMAE))
    print("all_time_maxR2: " + str(all_time_maxR2))
    print("all_time_maxNDCG: " + str(all_time_maxNDCG))

    print("all_iteration_count_minRMSE: " + str(min_val_index_RMSE + 1))
    print("all_iteration_count_minMAE: " + str(min_val_index_MAE + 1))
    print("all_iteration_count_maxR2: " + str(max_val_index_R2 + 1))
    print("all_iteration_count_maxNDCG: " + str(max_val_index_NDCG + 1))

    print("per_time_avg_RMSE: " + str(per_time_avg_RMSE))
    print("per_time_avg_MAE: " + str(per_time_avg_MAE))
    print("per_time_avg_R2: " + str(per_time_avg_R2))
    print("per_time_avg_NDCG: " + str(per_time_avg_NDCG))

    val_result_file.write("min_val_RMSE: " + str(min_val_RMSE) + "\n")
    val_result_file.write("min_val_MAE: " + str(min_val_MAE) + "\n")
    val_result_file.write("max_val_R2: " + str(max_val_R2) + "\n")
    val_result_file.write("max_val_NDCG: " + str(max_val_NDCG) + "\n")

    test_result_file.write("min_test_RMSE: " + str(min_test_RMSE) + "\n")
    test_result_file.write("min_test_MAE: " + str(min_test_MAE) + "\n")
    test_result_file.write("max_test_R2: " + str(max_test_R2) + "\n")
    test_result_file.write("max_test_NDCG: " + str(max_test_NDCG) + "\n")

    val_result_file.write("all_time_minRMSE: " + str(all_time_minRMSE) + "\n")
    val_result_file.write("all_time_minMAE: " + str(all_time_minMAE) + "\n")
    val_result_file.write("all_time_maxR2: " + str(all_time_maxR2) + "\n")
    val_result_file.write("all_time_maxNDCG: " + str(all_time_maxNDCG) + "\n")

    test_result_file.write("all_time_minRMSE: " + str(all_time_minRMSE) + "\n")
    test_result_file.write("all_time_minMAE: " + str(all_time_minMAE) + "\n")
    test_result_file.write("all_time_maxR2: " + str(all_time_maxR2) + "\n")
    test_result_file.write("all_time_maxNDCG: " + str(all_time_maxNDCG) + "\n")

    val_result_file.write("all_iteration_count_minRMSE: " + str(min_val_index_RMSE + 1) + "\n")
    val_result_file.write("all_iteration_count_minMAE: " + str(min_val_index_MAE + 1) + "\n")
    val_result_file.write("all_iteration_count_maxR2: " + str(max_val_index_R2 + 1) + "\n")
    val_result_file.write("all_iteration_count_maxNDCG: " + str(max_val_index_NDCG + 1) + "\n")

    test_result_file.write("all_iteration_count_minRMSE: " + str(min_val_index_RMSE + 1) + "\n")
    test_result_file.write("all_iteration_count_minMAE: " + str(min_val_index_MAE + 1) + "\n")
    test_result_file.write("all_iteration_count_maxR2: " + str(max_val_index_R2 + 1) + "\n")
    test_result_file.write("all_iteration_count_maxNDCG: " + str(max_val_index_NDCG + 1) + "\n")

    val_result_file.write("per_time_avg_RMSE: " + str(per_time_avg_RMSE) + "\n")
    val_result_file.write("per_time_avg_MAE: " + str(per_time_avg_MAE) + "\n")
    val_result_file.write("per_time_avg_R2: " + str(per_time_avg_R2) + "\n")
    val_result_file.write("per_time_avg_NDCG: " + str(per_time_avg_NDCG) + "\n")

    test_result_file.write("per_time_avg_RMSE: " + str(per_time_avg_RMSE) + "\n")
    test_result_file.write("per_time_avg_MAE: " + str(per_time_avg_MAE) + "\n")
    test_result_file.write("per_time_avg_R2: " + str(per_time_avg_R2) + "\n")
    test_result_file.write("per_time_avg_NDCG: " + str(per_time_avg_NDCG) + "\n")
    val_result_file.close()
    test_result_file.close()


if __name__ == '__main__':
    torch.cuda.set_device(1)
    for idx in [""]:
        for lr in [1e-3]:
            for alpha in [0.5]:
                for layers in [3]:
                    for dim in [64]:
                        for name in ["condmat"]:
                            main(lr, 1e-4, 2048, name, "Adam", dim, layers, "20240520" + str(idx), alpha, True, True, True, idx)  # L, P, H


