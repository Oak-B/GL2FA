from scipy.sparse import csr_matrix
import numpy as np
import scipy.sparse as sp
import torch
import time
import warnings

warnings.filterwarnings("ignore")
GPU = torch.cuda.is_available()
device = torch.device('cuda' if GPU else "cpu")

class Data:
    def __init__(self, train_file, val_file, test_file, dataset_name, batch_size=256, use_priori=True, use_holistic=True):
        self.train_file = train_file
        self.val_file = val_file
        self.test_file = test_file
        self.batch_size = batch_size
        self.dataset_name = dataset_name
        self.use_priori = use_priori
        self.use_holistic = use_holistic

        self.Graph = None
        self.delimiter = ":"
        self.max_row_id = -1
        self.max_col_id = -1
        """
            Reading Data
        """
        print("start loading data...")
        self.train_row = []
        self.train_col = []
        self.train_weight = []
        self.train_all_weights = 0.0
        with open(self.train_file, 'r') as file:
            for line in file.readlines():
                parts = line.strip().split(self.delimiter)
                row_id = int(float(parts[0]))
                col_id = int(float(parts[1]))
                weight = float(parts[2])
                self.train_all_weights = self.train_all_weights + weight
                self.max_row_id = row_id if row_id > self.max_row_id else self.max_row_id
                self.max_col_id = col_id if col_id > self.max_col_id else self.max_col_id
                self.train_row.append(row_id - 1)
                self.train_col.append(col_id - 1)
                self.train_weight.append(weight)
        self.val_row = []
        self.val_col = []
        self.val_weight = []
        self.val_all_weights = 0.0
        with open(self.val_file, 'r') as file:
            for line in file.readlines():
                parts = line.strip().split(self.delimiter)
                row_id = int(float(parts[0]))
                col_id = int(float(parts[1]))
                weight = float(parts[2])
                self.val_all_weights = self.val_all_weights + weight
                self.max_row_id = row_id if row_id > self.max_row_id else self.max_row_id
                self.max_col_id = col_id if col_id > self.max_col_id else self.max_col_id
                self.val_row.append(row_id - 1)
                self.val_col.append(col_id - 1)
                self.val_weight.append(weight)
        self.test_row = []
        self.test_col = []
        self.test_weight = []
        self.test_all_weights = 0.0
        with open(self.test_file, 'r') as file:
            for line in file.readlines():
                parts = line.strip().split(self.delimiter)
                row_id = int(float(parts[0]))
                col_id = int(float(parts[1]))
                weight = float(parts[2])
                self.test_all_weights = self.test_all_weights + weight
                self.max_row_id = row_id if row_id > self.max_row_id else self.max_row_id
                self.max_col_id = col_id if col_id > self.max_col_id else self.max_col_id
                self.test_row.append(row_id - 1)
                self.test_col.append(col_id - 1)
                self.test_weight.append(weight)
        """
            Cahning Data
        """
        self.train_data = csr_matrix(
            (self.train_weight, (self.train_row, self.train_col)), shape=(
                self.max_row_id, self.max_col_id), dtype='float32')
        self.val_data = csr_matrix(
            (self.val_weight, (self.val_row, self.val_col)), shape=(
                self.max_row_id, self.max_col_id), dtype='float32')
        self.test_data = csr_matrix(
            (self.test_weight, (self.test_row, self.test_col)), shape=(
                self.max_row_id, self.max_col_id), dtype='float32')
        """
            Construction to Adajcency Matrix
        """
        if self.use_priori is True:
            self.RowColNet = csr_matrix(
                                (self.train_weight, (self.train_row, self.train_col)), shape=(
                                                   self.max_row_id, self.max_col_id), dtype='float32')
        else:
            self.RowColNet = csr_matrix(
               (np.ones(len(self.train_row)), (self.train_row, self.train_col)), shape=(
                   self.max_row_id, self.max_col_id), dtype='float32')
        self.build_graph()
        self.train_truth_mean = self.train_all_weights / len(self.train_row)
        self.val_truth_mean = self.val_all_weights / len(self.val_row)
        self.test_truth_mean = self.test_all_weights / len(self.test_row)

        """
            Calculate IDCG
        """
        self.train_IDCG, self.val_IDCG, self.test_IDCG = self.computeIDCG(20)
        print("Number of entires:", len(self.train_row)+len(self.val_row)+len(self.test_row))
        print("Number of rows:", self.max_row_id, "Number of cols:", self.max_col_id)
        print("Nodes' degree:", self.degree.shape)
        print("loading data done...")

    def computeIDCG(self, top_k):
        train_IDCG = np.zeros(self.max_row_id)
        val_IDCG = np.zeros(self.max_row_id)
        test_IDCG = np.zeros(self.max_row_id)

        for u in range(self.max_row_id):
            # train
            cur_sorted_weights = np.sort(self.train_data[u].data)
            cur_sorted_weights = cur_sorted_weights[::-1]
            real_k = min(top_k, len(cur_sorted_weights))
            for k in range(real_k):
                train_IDCG[u] += ((2 ** cur_sorted_weights[k] - 1) / np.log2(k + 2))

            # val
            cur_sorted_weights = np.sort(self.val_data[u].data)
            cur_sorted_weights = cur_sorted_weights[::-1]
            real_k = min(top_k, len(cur_sorted_weights))
            for k in range(real_k):
                val_IDCG[u] += ((2 ** cur_sorted_weights[k] - 1) / np.log2(k + 2))

            # test
            cur_sorted_weights = np.sort(self.test_data[u].data)
            cur_sorted_weights = cur_sorted_weights[::-1]
            real_k = min(top_k, len(cur_sorted_weights))
            for k in range(real_k):
                test_IDCG[u] += ((2 ** cur_sorted_weights[k] - 1) / np.log2(k + 2))

        return train_IDCG, val_IDCG, test_IDCG

    def _convert_sp_mat_to_sp_tensor(self, X):
        coo = X.tocoo().astype(np.float32)
        row = torch.Tensor(coo.row).long()
        col = torch.Tensor(coo.col).long()
        index = torch.stack([row, col])
        data = torch.FloatTensor(coo.data)
        return torch.sparse.FloatTensor(index, data, torch.Size(coo.shape))

    def build_graph(self):
        try:
            pre_adj_mat = sp.load_npz('pre_adj_mat/' + self.dataset_name + '_s_pre_adj_mat.npz')
            print("successfully loaded...")
            norm_adj = pre_adj_mat
        except:
            s = time.time()
            R_coo = self.RowColNet.tocoo()
            R_row = R_coo.row
            R_col = R_coo.col + self.max_row_id
            R_data = R_coo.data
            adj_row = np.hstack((R_col, R_row))
            adj_col = np.hstack((R_row, R_col))
            adj_data = np.hstack((R_data, R_data))
            adj_coo = sp.coo_matrix((adj_data, (adj_row, adj_col)))

            print("adj_coo_size: ", adj_coo.shape)
            adj_mat = adj_coo.todok()
            self.degree = np.array(adj_mat.sum(axis=1))
            self.degree = torch.Tensor(self.degree)
            self.degree = self.degree.squeeze()
            self.degree = torch.where(self.degree == 0, torch.tensor(1e-4), self.degree)

            if self.use_holistic is not True:
                adj_mat = adj_mat + sp.eye(adj_mat.shape[0])

            rowsum = np.array(adj_mat.sum(axis=1))
            d_inv = np.power(rowsum, -0.5).flatten()
            d_inv[np.isinf(d_inv)] = 0.
            d_mat = sp.diags(d_inv)

            norm_adj = d_mat.dot(adj_mat)
            norm_adj = norm_adj.dot(d_mat)
            norm_adj = norm_adj.tocsr()
            end = time.time()
            print('costing ' + str(end - s) + 's, saved norm_mat...')

        self.Graph = self._convert_sp_mat_to_sp_tensor(norm_adj)
        self.Graph = self.Graph.coalesce().to(device)

    def train_iterate_one_epoch(self, batch_size):
        row_temp = self.train_row[:]
        col_temp = self.train_col[:]
        labels_temp = self.train_weight[:]

        num_training = len(labels_temp)
        total_batch = int(num_training / batch_size)

        idxs = np.random.permutation(num_training)  # shuffled ordering
        row_random = list(np.array(row_temp)[idxs])
        col_random = list(np.array(col_temp)[idxs])
        labels_random = list(np.array(labels_temp)[idxs])

        return row_random, col_random, labels_random, total_batch, num_training

    def val_iterate_one_epoch(self, batch_size):
        row_temp = self.val_row[:]
        col_temp = self.val_col[:]
        labels_temp = self.val_weight[:]

        num_val = len(labels_temp)
        total_batch = int(num_val / batch_size)

        idxs = np.random.permutation(num_val)  # shuffled ordering
        row_random = list(np.array(row_temp)[idxs])
        col_random = list(np.array(col_temp)[idxs])
        labels_random = list(np.array(labels_temp)[idxs])

        return row_random, col_random, labels_random, total_batch, num_val

    def test_iterate_one_epoch(self, batch_size):
        row_temp = self.test_row[:]
        col_temp = self.test_col[:]
        labels_temp = self.test_weight[:]

        num_testing = len(labels_temp)
        total_batch = int(num_testing / batch_size)

        idxs = np.random.permutation(num_testing)  # shuffled ordering
        row_random = list(np.array(row_temp)[idxs])
        col_random = list(np.array(col_temp)[idxs])
        labels_random = list(np.array(labels_temp)[idxs])

        return row_random, col_random, labels_random, total_batch, num_testing
