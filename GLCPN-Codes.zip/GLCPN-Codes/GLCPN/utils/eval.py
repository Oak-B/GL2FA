import torch

def eval(truth, preds, mean):
    # for estimation accuracy
    temp_RMSE = torch.sum((preds - truth)**2).item()
    temp_MAE = torch.sum(torch.abs(preds - truth)).item()
    temp_SSE = torch.sum((preds - truth)**2).item()
    temp_SST = torch.sum((mean - truth)**2).item()

    return temp_RMSE, temp_MAE, temp_SSE, temp_SST
