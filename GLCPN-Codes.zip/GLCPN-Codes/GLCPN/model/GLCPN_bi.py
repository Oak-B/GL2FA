import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
from torch.autograd import Variable
import numpy as np
import random
import math
import time
import torch_sparse

def seed_torch(seed=2024):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

def weigth_init(m):
    if isinstance(m, nn.Conv2d):
        init.xavier_uniform_(m.weight.data)
        init.constant_(m.bias.data,0.1)
    elif isinstance(m, nn.BatchNorm2d):
        m.weight.data.fill_(1)
        m.bias.data.zero_()
    elif isinstance(m, nn.Linear):
        init.xavier_normal_(m.weight.data)
        m.bias.data.zero_()
    elif isinstance(m, nn.Embedding):
        init.xavier_normal(m.weight.data)

class GLCPN(nn.Module):
    def __init__(self, num_rows, num_cols, latent_dim, n_layers, graph, alpha, degree, use_holistic, use_linear):
        """
        A GLCPN Model

        :param num_rows:
        :param num_cols:
        :param latent_dim:
        :param n_layers:
        :param graph:
        :param alpha:
        :param degree:
        :param use_holistic:
        :param use_linear:
        """
        super(GLCPN, self).__init__()
        seed_torch()

        self.num_rows = num_rows
        self.num_cols = num_cols
        self.n_layers = n_layers
        self.graph = graph
        self.alpha = alpha
        self.degree = degree
        self.beta = 1 - alpha
        self.training = None
        self.latent_dim = latent_dim
        self.use_holistic = use_holistic
        self.use_linear = use_linear
        # self._colGraph = torch.FloatTensor(norm_adj).cuda()
        # self.denseGraph = colGraph.to_dense()
        # embedding layer
        self.embedding_row = nn.Embedding(num_embeddings=num_rows, embedding_dim=latent_dim).apply(
            weigth_init).cuda()
        self.embedding_col = nn.Embedding(num_embeddings=num_cols, embedding_dim=latent_dim).apply(
            weigth_init).cuda()

        self.eps = nn.Parameter(torch.randn(1), requires_grad=True)

        self.weight_dict = nn.ParameterDict()
        for k in range(self.n_layers):
            self.weight_dict.update({'W_gc_%d' % k: nn.Parameter(init.xavier_normal(torch.empty(latent_dim,
                                                                                                latent_dim)))})
            self.weight_dict.update({'b_gc_%d' % k: nn.Parameter(init.xavier_normal(torch.empty(1, latent_dim)))})

    def forward(self, row_input, col_input):
        if self.training == True:
            # 变成对称的
            rows_emb = self.embedding_row.weight
            cols_emb = self.embedding_col.weight

            # concated embeddings of rows and cols: first layer E
            all_emb = torch.cat([rows_emb, cols_emb])

            # all layers embs, here adding the first layer
            embs = [all_emb]

            # calculate the remaining layers embs
            for layer in range(self.n_layers):
                # all_emb = torch.sparse.mm(self.graph, all_emb)
                all_emb = torch_sparse.spmm(self.graph.coalesce().indices(),
                                              self.graph.coalesce().values(),
                                              self.num_rows + self.num_cols,
                                              self.num_rows + self.num_cols,
                                              all_emb)

                if self.use_linear is not True:
                    all_emb = torch.matmul(all_emb, self.weight_dict['W_gc_%d' % layer]) \
                                + self.weight_dict['b_gc_%d' % layer]

                    all_emb = torch.relu(all_emb)

                embs.append(all_emb)

            if self.use_holistic is True:
                # ours
                avg = self.alpha * embs[0]

                eps_degree = 1e-4 * torch.sigmoid(self.eps.cuda()) / (self.degree.cuda())
                eps_degree = eps_degree.unsqueeze(1).expand(self.num_rows + self.num_cols, self.latent_dim)
                avg += torch.mul(eps_degree, embs[0])

                for i in range(self.n_layers):
                    avg += embs[i + 1] * self.alpha * self.beta ** (i + 1)
                self.rows_avg, self.cols_avg = torch.split(avg, [self.num_rows, self.num_cols])
            else:
                avg = all_emb
                self.rows_avg, self.cols_avg = torch.split(avg, [self.num_rows, self.num_cols])

        rows_emb = self.rows_avg[row_input]
        cols_emb = self.cols_avg[col_input]

        # calculate the preds
        inner_pro = torch.mul(rows_emb, cols_emb)
        preds = torch.sum(inner_pro, dim=1)

        return preds

