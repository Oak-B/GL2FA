import torch
import torch.nn as nn
from torch.nn import init
import numpy as np
import random
import torch_sparse

def seed_torch(seed=2024):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

def weigth_init(m):
    if isinstance(m, nn.Conv2d):
        init.xavier_uniform_(m.weight.data)
        init.constant_(m.bias.data,0.1)
    elif isinstance(m, nn.BatchNorm2d):
        m.weight.data.fill_(1)
        m.bias.data.zero_()
    elif isinstance(m, nn.Linear):
        init.xavier_normal_(m.weight.data)
        m.bias.data.zero_()
    elif isinstance(m, nn.Embedding):
        init.xavier_normal(m.weight.data)

class GLCPN(nn.Module):
    def __init__(self, num_rows, num_cols, latent_dim, n_layers, ui_graph, alpha, degree, use_holistic, use_linear):
        """
        A GLCPN Model

        :param num_rows:
        :param num_cols:
        :param latent_dim:
        :param n_layers:
        :param ui_graph:
        :param alpha:
        :param degree:
        :param use_holistic:
        :param use_linear:
        """
        super(GLCPN, self).__init__()
        # seed_torch()

        self.num_rows = num_rows
        self.num_cols = num_cols
        self.n_layers = n_layers
        self.alpha = alpha
        self.degree = degree
        self.beta = 1 - alpha
        self.training = None
        self.latent_dim = latent_dim
        self.use_holistic = use_holistic
        self.use_linear = use_linear
        self.ui_graph = ui_graph

        # embedding layer
        self.embedding_row = nn.Embedding(num_embeddings=num_rows, embedding_dim=latent_dim).apply(
            weigth_init).cuda()
        self.embedding_col = nn.Embedding(num_embeddings=num_cols, embedding_dim=latent_dim).apply(
            weigth_init).cuda()

        self.eps = nn.Parameter(torch.randn(1), requires_grad=True)

        self.weight_dict = nn.ParameterDict()
        for k in range(self.n_layers):
            self.weight_dict.update({'W_gc_%d' % k: nn.Parameter(init.xavier_normal(torch.empty(latent_dim,
                                                                                                latent_dim)))})
            self.weight_dict.update({'b_gc_%d' % k: nn.Parameter(init.xavier_normal(torch.empty(1, latent_dim)))})

            self.weight_dict.update({'W_bi_%d' % k: nn.Parameter(init.xavier_normal(torch.empty(latent_dim,
                                                                                                latent_dim)))})
            self.weight_dict.update({'b_bi_%d' % k: nn.Parameter(init.xavier_normal(torch.empty(1, latent_dim)))})

    def forward(self, row_input, col_input):
        rows_emb = self.embedding_row.weight
        cols_emb = self.embedding_col.weight

        rows_embs = [rows_emb]
        cols_embs = [cols_emb]

        for layer in range(self.n_layers):
            rows_emb = torch_sparse.spmm(self.ui_graph.coalesce().indices(),
                                          self.ui_graph.coalesce().values(),
                                          self.num_rows,
                                          self.num_rows,
                                          rows_emb)
            cols_emb = torch_sparse.spmm(self.ui_graph.coalesce().indices(),
                                          self.ui_graph.coalesce().values(),
                                          self.num_cols,
                                          self.num_cols,
                                          cols_emb)

            if self.use_linear is not True:
                rows_emb = torch.matmul(rows_emb, self.weight_dict['W_bi_%d' % layer]) \
                            + self.weight_dict['b_bi_%d' % layer]
                cols_emb = torch.matmul(cols_emb, self.weight_dict['W_gc_%d' % layer]) \
                            + self.weight_dict['b_gc_%d' % layer]

                rows_emb = torch.relu(rows_emb)
                cols_emb = torch.relu(cols_emb)

            rows_embs.append(rows_emb)
            cols_embs.append(cols_emb)

        if self.use_holistic is True:
            self.rows_avg = self.alpha * rows_embs[0]
            self.cols_avg = self.alpha * cols_embs[0]

            eps_degree = 1e-4 * torch.sigmoid(self.eps.cuda()) / (self.degree.cuda())
            eps_degree = eps_degree.unsqueeze(1).expand(self.num_rows, self.latent_dim)
            self.rows_avg += torch.mul(eps_degree, rows_embs[0])
            self.cols_avg += torch.mul(eps_degree, cols_embs[0])

            for i in range(self.n_layers):
                self.rows_avg += rows_embs[i + 1] * self.alpha * self.beta ** (i + 1)
                self.cols_avg += cols_embs[i + 1] * self.alpha * self.beta ** (i + 1)
        else:
            self.rows_avg = rows_emb
            self.cols_avg = cols_emb

        rows_emb = self.rows_avg[row_input]
        cols_emb = self.cols_avg[col_input]

        inner_pro = torch.mul(rows_emb, cols_emb)
        preds = torch.sum(inner_pro, dim=1)

        return preds

    def __dropout_x(self, x, keep_prob):
        size = x.size()
        index = x.indices().t()
        values = x.values()
        random_index = torch.rand(len(values)) + keep_prob
        random_index = random_index.int().bool()
        index = index[random_index]
        values = values[random_index] / keep_prob
        g = torch.sparse.FloatTensor(index.t(), values, size)
        return g

    def __dropout(self, keep_prob):
        if self.A_split:
            graph = []
            for g in self.Graph:
                graph.append(self.__dropout_x(g, keep_prob))
        else:
            graph = self.__dropout_x(self.ui_graph, keep_prob)
        return graph

